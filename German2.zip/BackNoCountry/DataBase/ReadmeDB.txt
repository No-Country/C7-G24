Cree un archivo script para la base de datos de prueba. 
Use MySQL workbench, tambien esta el modelo, hay 4 tablas, empresa, donante, alimentos y voluntario. 
