package com.bdabalcarce.demo.Dto;

import jakarta.validation.constraints.NotBlank;



public class companyDto {

    @NotBlank
    private String coName;

    @NotBlank
    private String coEmail;

    @NotBlank
    private String coAdress;

    @NotBlank
    private String coCUIT;

    @NotBlank
    private String coPhone;

    @NotBlank
    private String coCategory;

    private String coContactName;

    private String coContactLastName;

    public companyDto() {
    }

    public companyDto(String coName, String coEmail, String coAdress, String coCUIT, String coPhone, String coCategory, String coContactName, String coContactLastName) {
        this.coName = coName;
        this.coEmail = coEmail;
        this.coAdress = coAdress;
        this.coCUIT = coCUIT;
        this.coPhone = coPhone;
        this.coCategory = coCategory;
        this.coContactName = coContactName;
        this.coContactLastName = coContactLastName;
    }

    public String getCoName() {
        return coName;
    }

    public void setCoName(String coName) {
        this.coName = coName;
    }

    public String getCoEmail() {
        return coEmail;
    }

    public void setCoEmail(String coEmail) {
        this.coEmail = coEmail;
    }

    public String getCoAdress() {
        return coAdress;
    }

    public void setCoAdress(String coAdress) {
        this.coAdress = coAdress;
    }

    public String getCoCUIT() {
        return coCUIT;
    }

    public void setCoCUIT(String coCUIT) {
        this.coCUIT = coCUIT;
    }

    public String getCoPhone() {
        return coPhone;
    }

    public void setCoPhone(String coPhone) {
        this.coPhone = coPhone;
    }

    public String getCoCategory() {
        return coCategory;
    }

    public void setCoCategory(String coCategory) {
        this.coCategory = coCategory;
    }

    public String getCoContactName() {
        return coContactName;
    }

    public void setCoContactName(String coContactName) {
        this.coContactName = coContactName;
    }

    public String getCoContactLastName() {
        return coContactLastName;
    }

    public void setCoContactLastName(String coContactLastName) {
        this.coContactLastName = coContactLastName;
    }
}