package com.bdabalcarce.demo.controller;


import com.bdabalcarce.demo.Dto.companyDto;
import com.bdabalcarce.demo.entity.company;
import com.bdabalcarce.demo.service.companyS;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController

@RequestMapping({"/empresas"})
public class companyController {
    @Autowired
    companyS companyServ;

    @GetMapping ("/listar")
    public ResponseEntity<List<company>> list() {
        List<company> list = companyServ.list();
        return new ResponseEntity(list, HttpStatus.OK);
    }

    @PostMapping("/create")
    public ResponseEntity<?> create(@RequestBody companyDto dtoempresa) {
        if (StringUtils.isBlank(dtoempresa.getCoName())) {
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        }

        company Company = new company(dtoempresa.getCoName(),
                dtoempresa.getCoCategory(),
                dtoempresa.getCoCUIT(),
                dtoempresa.getCoAdress(),
                dtoempresa.getCoEmail(),
                dtoempresa.getCoPhone(),
                dtoempresa.getCoContactName(),
                dtoempresa.getCoContactLastName());
        companyServ.save(Company);

        return new ResponseEntity(HttpStatus.OK);
    }

}

