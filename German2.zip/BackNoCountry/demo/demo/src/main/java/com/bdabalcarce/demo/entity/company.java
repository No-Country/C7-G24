package com.bdabalcarce.demo.entity;


import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;

@Entity
public class company implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //campo primary key autogenerado
    private int id_company;

    @NotNull
    @Size(min = 1, max = 50)
    private String coName;

    @Size(min = 1, max = 50)
    private String coCUIT;

    @Size(min = 1, max = 50)
    private String coPhone;

    @Size(min = 1, max = 50)
    private String coAdress;

    @Size(min = 1, max = 50)
    private String coContactName;

    @Size(min = 1, max = 50)
    private String coContactLastName;

    @NotNull
    @Size (min = 1, max = 50)
    private String coCategory;

    @NotNull
    @Size (min = 1, max = 50)
    private String coEmail;

    public company() {
    }

    public company( String coName, String coCUIT, String coPhone, String coAdress, String coContactName, String coContactLastName, String coCategory, String coEmail) {
        this.coName = coName;
        this.coCUIT = coCUIT;
        this.coPhone = coPhone;
        this.coAdress = coAdress;
        this.coContactName = coContactName;
        this.coContactLastName = coContactLastName;
        this.coCategory = coCategory;
        this.coEmail = coEmail;
    }

    public int getId_company() {
        return id_company;
    }

    public void setId_company(int id_company) {
        this.id_company = id_company;
    }

    public String getCoName() {
        return coName;
    }

    public void setCoName(String coName) {
        this.coName = coName;
    }

    public String getCoCUIT() {
        return coCUIT;
    }

    public void setCoCUIT(String coCUIT) {
        this.coCUIT = coCUIT;
    }

    public String getCoPhone() {
        return coPhone;
    }

    public void setCoPhone(String coPhone) {
        this.coPhone = coPhone;
    }

    public String getCoAdress() {
        return coAdress;
    }

    public void setCoAdress(String coAdress) {
        this.coAdress = coAdress;
    }

    public String getCoContactName() {
        return coContactName;
    }

    public void setCoContactName(String coContactName) {
        this.coContactName = coContactName;
    }

    public String getCoContactLastName() {
        return coContactLastName;
    }

    public void setCoContactLastName(String coContactLastName) {
        this.coContactLastName = coContactLastName;
    }

    public String getCoCategory() {
        return coCategory;
    }

    public void setCoCategory(String coCategory) {
        this.coCategory = coCategory;
    }

    public String getCoEmail() {
        return coEmail;
    }

    public void setCoEmail(String coEmail) {
        this.coEmail = coEmail;
    }
}
