package com.bdabalcarce.demo.entity;


import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.io.Serializable;


@Entity
public class user implements Serializable{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) //campo primary key autogenerado
    private int id_user;

    @NotNull
    @Size(min = 1, max = 50)
    private String userName;

    @NotNull
    @Size(min = 1, max = 50)
    private String userLastname;

    @Size(min = 1, max = 50)
    private String userEmail;

    @Size(min = 1, max = 50)
    private String userPhone;

    @Size(min = 1, max = 50)
    private String userAdress;

    @Size(min = 1, max = 50)
    private String userVehicle;

    @Size(min = 1, max = 50)
    private String userAvailability;

    @NotNull
    @Size (min = 1, max = 50)
    private String userDNI;

    public user() {
    }

    public user(String userName, String userLastname, String userEmail, String userPhone, String userDireccion, String userVehicle, String userDiponibilidad, String userDNI) {
        this.userName = userName;
        this.userLastname = userLastname;
        this.userEmail = userEmail;
        this.userPhone = userPhone;
        this.userAdress = userAdress;
        this.userVehicle = userVehicle;
        this.userAvailability = userAvailability;
        this.userDNI = userDNI;
    }

    public int getId_user() {
        return id_user;
    }

    public void setId_user(int id_user) {
        this.id_user = id_user;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserLastname() {
        return userLastname;
    }

    public void setUserLastname(String userLastname) {
        this.userLastname = userLastname;
    }

    public String getEmail() {
        return userEmail;
    }

    public void setEmail(String email) {
        this.userEmail = email;
    }

    public String getPhone() {
        return userPhone;
    }

    public void setPhone(String phone) {
        this.userPhone = phone;
    }

    public String getAdress() {
        return userAdress;
    }

    public void setAdress(String Adress) {
        this.userAdress = Adress;
    }

    public String getVehicle() {
        return userVehicle;
    }

    public void setVehicle(String vehicle) {
        this.userVehicle = vehicle;
    }

    public String getAvailability() {
        return userAvailability;
    }

    public void setAvailability(String Availability) {this.userAvailability = Availability; }

    public String getUserDNI() {return userDNI; }

    public void setUserDNI(String userDNI) {this.userDNI = userDNI; }
}
