package com.bdabalcarce.demo.repository;

import com.bdabalcarce.demo.entity.company;
import org.springframework.data.jpa.repository.JpaRepository;

public interface companyRepo extends JpaRepository<company, Integer> {
}





